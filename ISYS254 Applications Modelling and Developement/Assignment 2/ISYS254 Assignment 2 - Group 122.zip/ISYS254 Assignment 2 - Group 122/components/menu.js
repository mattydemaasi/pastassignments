/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  TextInput,
  Image,
  TouchableOpacity,
} from 'react-native';

import { Dropdown } from 'react-native-material-dropdown';
import { Actions } from 'react-native-router-flux';

export default class home extends Component {

  constructor(props){
    super(props);
    let params =
    this.props.navigation.state.params;
    this.state = {
      finalValue: params.menuValue,
      food:"",
      foodquantity:0,
      drinks:"",
      drinksquantity:0
    };

    this.fooditem=[{
  							value:	' 🍠 Sweet Potato Fries - $10',
  					},	{
  							value:	' 🍔 BLT Burger - $12',
  					},	{
  							value:	' 🍚 Fried Rice - $99',
  					},	{
  							value:	' 🥟 BBQ Pork Bun - $13',
  					},	{
  							value:	' 🍣 Salmon Nigri - $34',
  					}];

    this.foodquantity =	[{
                value:	' 1',
            },	{
                value:	' 2',
            },	{
                value:	' 3',
            },	{
                value:	' 4',
            },	{
                value:	' 5',
            }];

    this.drinks =	[{
          							value:	' 🥤 Coke - $2',
          					},	{
          							value:	' 🥃 Red Bull - $9',
          					},	{
          							value:	' 🥤 Milkshake - $5',
          					},	{
          							value:	' ☕️ Latte - $3',
          					},	{
          							value:	' 🥤 Smoothie - $6',
          					}];

   this.drinksquantity =	[{
                        value:	'1',
                    },	{
                      	value:	'2',
                    },	{
                        value:	'3',
                    },	{
                        value:	'4',
                    },	{
                        value:	'5',
                    }];
  }

  render() {

    return (
      <View style={styles.container}>
      <View style={styles.container1}>
      <Text style={{fontSize: 35, color: 'black', backgroundColor: 'white', borderWidth:2, borderRadius: 10}}> {this.state.finalValue} </Text>
      </View>
        <View style={styles.viewRow2}>

                <Dropdown
                      containerStyle={styles.dropdown1}
                      label=' Food Item'
                      data={this.fooditem}
                      onChangeText={(chosenValue) => this.setState({
                        food:chosenValue
                        }
                        )}
                        />

                <Dropdown
                      containerStyle={styles.dropdown2}
                      label=' Quantity'
                      data={this.foodquantity}
                      onChangeText={(chosenValue) => this.setState({
                        foodquantity:chosenValue
                        }
                        )}
                        />
        </View>
        <View style={styles.viewRow2}>

                <Dropdown
                      containerStyle={styles.dropdown1}
                      label=' Drinks'
                      data= {this.drinks}
                      onChangeText={(chosenValue) => this.setState({
                        drinks:chosenValue
                        }
                        )}
                        />

                <Dropdown
                      containerStyle={styles.dropdown2}
                      label=' Quantity'
                      data={this.foodquantity}
                      onChangeText={(chosenValue) => this.setState({
                        drinksquantity:chosenValue
                        }
                        )}
                        />
        </View>
        <View style={styles.viewRow2}>
                <TouchableOpacity
                    style={styles.button}>
                    <Text style={styles.buttonText}
                    onPress={this.onPressEvent.bind(this)}>
                      Proceed
                    </Text>
                </TouchableOpacity>
        </View>
      </View>
    );
  }
  onPressEvent(){
 let tempfood = this.state.food
 let tempfoodprice = parseInt(tempfood.substring(tempfood.length-2,tempfood.length));

 let tempdrinks = this.state.drinks
 let tempdrinksprince = parseInt(tempdrinks.substring(tempdrinks.length-1,tempdrinks.length));

 let final = (tempfoodprice * this.state.foodquantity) + (tempdrinksprince * this.state.drinksquantity);

       Actions.summary({
       finalFood: tempfood,
       finalQuantity: this.state.foodquantity,
       finalDrink: tempdrinks,
       finalDrinkQuantity: this.state.drinksquantity,
       summaryValue:final
        });
      }
  }

const styles = StyleSheet.create({
  container:{
    flex: 1,
    backgroundColor: '#F36B6B',
  },
  container1:{
    paddingTop: 50,
    alignItems:'center',
  },
  viewRow2:{
    flex:1,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
  },
  viewRow3:{
    flex:1,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
  },
  dropdown1: {
    flex: 2.5,
    backgroundColor: 'white',
    marginTop: 70,
    marginLeft: 10,
    marginRight:10,
    alignItems: 'stretch',
    borderWidth: 1,
    borderRadius: 10,
  },
  dropdown2:{
    flex: 1,
    backgroundColor: 'white',
    marginTop: 70,
    marginRight:10,
    alignItems: 'stretch',
    borderWidth: 1,
    borderRadius: 10,
  },
  button:{
    backgroundColor:'white',
    height: 50,
    width: 280,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: -35,
    borderRadius:10,
    borderWidth: 2,
  },
  buttonText:{
    textAlign: 'center',
    fontSize: 20,
    color: 'black',
  }
});
