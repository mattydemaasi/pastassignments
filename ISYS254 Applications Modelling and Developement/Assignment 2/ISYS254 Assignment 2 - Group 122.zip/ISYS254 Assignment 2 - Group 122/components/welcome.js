/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  TextInput,
  Image,
  TouchableOpacity,
} from 'react-native';

import { Dropdown } from 'react-native-material-dropdown';
import { Actions } from 'react-native-router-flux';

export default class home extends Component {

  constructor(props){
    super(props);
    this.state={

    }

    this.business =	[{
  							value:	'🥤 Boost Juice',
  					},	{
  							value:	'🍔 Burger Freight',
  					},	{
  							value:	'🌯 Sambal',
  					},	{
  							value:	'🍱 Sushi World',
  					},	{
  							value:	'🍕 Ubar',
  					}];

  }


  render() {

    return (

      <View style={styles.container}>
      <View style={styles.container1}>
      <Image source={require('./csslogo.png')} style={styles.image}/>
      </View>
        <View style={styles.viewRow1}>
                <Dropdown
                    containerStyle={styles.dropdown1}
                    label=' Pick a Restaurant'
                    data={this.business}
                    onChangeText={(menuValue)	=>	this.setState({
																business:menuValue
                              }
                          														)}
                      />
        </View>
        <View style={styles.viewRow2}>
                <TouchableOpacity
                    style={styles.button}
                    onPress={this.onPressEvent.bind(this)}>
                    <Text style={styles.buttonText}>Proceed</Text>
                </TouchableOpacity>
        </View>
      </View>
    );
  }

  onPressEvent(){
    Actions.menu({
      menuValue:this.state.business
      });
  }

}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F36B6B',
  },
  container1:{
    flex: 1,
    paddingTop : 75,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },

  viewRow1:{
    flex:1,
    alignItems: 'center',
    marginTop: 100,
  },
  viewRow2:{
    flex:1,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
  },
  dropdown1: {
    backgroundColor:'white',
    height: 75,
    width:350,
    borderWidth:1,
    borderRadius:10,
  },
  button:{
      backgroundColor:'white',
      height: 50,
      width: 280,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: -90,
      borderRadius:10,
      borderWidth: 2,
  },
  buttonText:{
    textAlign: 'center',
    color:'black',
    fontSize: 20,

  },

    image: {
      height:200,
      width:200,
    }
});
