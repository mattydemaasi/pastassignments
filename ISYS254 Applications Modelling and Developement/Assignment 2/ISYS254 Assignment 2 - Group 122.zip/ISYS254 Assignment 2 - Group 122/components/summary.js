import React, { Component } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet
} from 'react-native';

export default class summary extends Component {

  constructor(props) {
    super(props);

    let params = this.props.navigation.state.params;
    this.state = {
      finalValue:params.summaryValue,
      finalFood: params.finalFood,
      finalDrink:params.finalDrink,
      finalFoodQuantity: params.finalQuantity,
      finalDrinkQuantity: params.finalDrinkQuantity,

    };
  }
  render() {

    return(
      <View style={styles.container}>
     <Text style={{marginTop:	30, fontSize: 24, color: 'black', marginLeft: 15, textAlign:'center', backgroundColor: 'white', borderWidth:1, borderRadius:10, width: 380}}>Thank you for Ordering with CSS!</Text>
     <Text style={{marginTop:	40, paddingLeft: 10, fontSize: 20, color: 'black'}}>	Order Summary: </Text>
     <Text style={{marginTop:	15, paddingLeft: 20, fontSize: 18, color: 'black'}}> 🍴Food: {this.state.finalFood} x {this.state.finalFoodQuantity}</Text>
     <Text style={{marginTop:	10, paddingLeft: 20, fontSize: 18, color: 'black'}}> 🥤Drink: {this.state.finalDrink} x {this.state.finalDrinkQuantity}</Text>
	   <Text style={{marginTop:	35, fontSize: 22, textAlign:'center', color: 'black'}}>	💰Total	Cost of Order: ${this.state.finalValue} 💰</Text>
  	 <Text style={{marginTop:	50, fontSize: 18, textAlign:'center', color: 'black',}}>Your order will be ready for pickup in 15 mins</Text>
     <Text style={{marginTop:	60, fontSize: 20, textAlign:'center', color: 'black',}}> App developed by JIM 👨🏻 or GYM 🏋🏻‍♂️ 🤔</Text>
     <Text style={{marginTop:	30, fontSize: 18, textAlign:'center', color: 'black',}}>Justin Lam - 45197083</Text>
     <Text style={{marginTop:	15, fontSize: 18, textAlign:'center', color: 'black',}}>Isaac Zhuan Jian Lee - 45526249</Text>
     <Text style={{marginTop:	15, fontSize: 18, textAlign:'center', color: 'black',}}>Matthew De Masi - 45585342 </Text>
      </View>

    );
  }

}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F36B6B',
  },
});
